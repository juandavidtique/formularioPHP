<?php
$nombre = $_POST['nombre'];
$edad = $_POST['edad'];
$email = $_POST['email'];
$departamento = $_POST['departamento'];
$municipio = $_POST['municipio'];
$genero = $_POST['genero'];
$acepto = $_POST['acepto'];
//


echo "$nombre, $edad, $email, $departamento, $municipio, $genero, $acepto";

// ::::::::: conexion :::::::::

// -------------- Variables de conexión ----------
$server = "127.0.0.1";
$database = "ejemplo_php";
$username = "root";
$password = "";
//--------------- Cadena de conexión ----------------
$conn = mysqli_connect($server, $username, $password, $database);
// Revisar la conexión
if(!$conn)
    die("Conexion fallida: " . mysqli_connect_error()); //Describe el error de conexion

echo "Conexion exitosa";

?>